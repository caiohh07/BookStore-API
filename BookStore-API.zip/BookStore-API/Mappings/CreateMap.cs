﻿namespace BookStore_API.Mappings
{
    internal class CreateMap<T1, T2>
    {
    }
}